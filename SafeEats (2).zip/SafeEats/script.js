'use strict';


const api_url = "https://api.edamam.com/api/food-database/v2/parser?";
const app_id = "app_id=5952ffac";
const app_key = "&app_key=791ac5c74c2c3176b2b830d9f435c7bd";

var url = api_url + app_id + app_key + "&ingr=wheat";


async function getapi(url){

    const response = await fetch(url);

    var data = await response.json();
    console.log(data); 
}

getapi(url);